from operator import add
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import string
import random
import pyperclip
import json

letters = list(string.ascii_letters)
numbers = list(string.digits)
symbols = list(string.punctuation)
symbols.remove("|")
# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_pass():
    password = []
    for _ in range(5):
        password.extend([random.choice(letters), random.choice(numbers), random.choice(symbols)])
    random.shuffle(password)
    password = "".join(password)
    password_var.set(password)
    pyperclip.copy(password)


# ---------------------------- SAVE PASSWORD ------------------------------- #
def save_password():
    website = website_entry.get().strip()
    email = email_entry.get().strip()
    password = password_var.get().strip()
    new_data = {
        website: {
            "email": email,
            "password": password,
        }
    }
    if len(website) == 0 or len(password) == 0:
        messagebox.showinfo(title="Oops", message="Please make sure you haven't left any fields empty.")
    else:
        try:
            with open("data.json", "r") as data_file:
                data = json.load(data_file)
        except FileNotFoundError:
            with open("data.json", "w") as data_file:
                json.dump(new_data, data_file, indent=4)
        else:
            data.update(new_data)
            with open("data.json", "w") as data_file:
                json.dump(data, data_file, indent=4)
            messagebox.showinfo(title="Nice", message="Added.")
        finally:
            website_entry.delete(0, END)
            password_var.set("")
# ---------------------------- FIND PASSWORD ------------------------------- #
def find_password():
    website = website_entry.get().strip()
    try:
        with open("data.json") as data_file:
            data = json.load(data_file)
    except FileNotFoundError:
        messagebox.showinfo(title="Error", message="No Data File Found.")
    else:
        if website in data:
            email = data[website]["email"]
            password = data[website]["password"]
            pyperclip.copy(password)
            messagebox.showinfo(title=website, message=f"Email: {email}\nPassword: {password}\n\nPassword copied.")
        else:
            messagebox.showinfo(title="Error", message=f"No details for {website} exists.")

# ---------------------------- UI SETUP ------------------------------- #


window = Tk()
window.title("Password manager")
window.config(padx=50, pady=50)

my_img = PhotoImage(file="logo.png")
canvas = Canvas(width=200, height=200, highlightthickness=0)
canvas.create_image(60, 100, image = my_img)
canvas.grid(column=1, row=0)

#Labels
website = ttk.Label(text="Website")
website.grid(column=0, row=1)

email = ttk.Label(text="Email/Username")
email.grid(column=0, row=2)

password = ttk.Label(text="Password")
password.grid(column=0, row=3)

#Entries
website_entry = ttk.Entry(width=43)
website_entry.grid(column=1, row=1)
website_entry.focus()

email_entry = ttk.Entry(width=43)
email_entry.grid(column=1, row=2)
email_entry.insert(0, "ogabekkushmuratov@gmail.com")

password_var = StringVar()
password_entry = ttk.Entry(width=20, textvariable=password_var)
password_entry.grid(column=1, row=3, sticky="w")
#Buttons
generate_password = ttk.Button(text="Generate Password", width=20, command=generate_pass)
generate_password.grid(column=1, row=3, sticky="e", pady=3)

add_button = ttk.Button(text="Add", width=43, command=save_password)
add_button.grid(column=1, row=4)

find_button = ttk.Button(text="Find Password", width=43, command=find_password)
find_button.grid(column=1, row=5)













window.mainloop()